﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CodeGenerationLib
{
    public static class StringSearchService
    {

        public static StringRange FindNextOccurenceForwards(string s, string toSearchFor, int startIndex = 0, int endIndex = -1, bool ignoreCase = false)
        {
            if (string.IsNullOrEmpty(toSearchFor))
                return null;
            if (ignoreCase)
                s = s.ToLower();
            if (endIndex == -1)
                endIndex = s.Length - 1;

            int start = s.IndexOf(toSearchFor, startIndex, ignoreCase ? StringComparison.OrdinalIgnoreCase : StringComparison.Ordinal);
            var result = new StringRange(start, start + toSearchFor.Length - 1);
            if (start == -1 || result.End > endIndex)
                return null;
            return result;
        }

        public static StringRange FindNextOccurenceBackwards(string s, string toSearchFor, int startIndex = -1, int endIndex = 0, bool ignoreCase = false)
        {
            if (string.IsNullOrEmpty(toSearchFor))
                return null;
            if (ignoreCase)
                s = s.ToLower();
            if (startIndex == -1)
                startIndex = s.Length - 1;
            
            int start = s.LastIndexOf(toSearchFor, startIndex, ignoreCase ? StringComparison.OrdinalIgnoreCase : StringComparison.Ordinal);
            var result = new StringRange(start, start + toSearchFor.Length - 1);
            if (start == -1 || result.Start < endIndex)
                return null;
            return result;
        }

        public static List<StringRange> FindAllOccurencesForwards(string s, string toSearchFor, int startIndex = 0, int endIndex = -1, bool ignoreCase = false)
        {
            if (ignoreCase)
                s = s.ToLower();
            var resultList = new List<StringRange>();
            var stringRange = FindNextOccurenceForwards(s, toSearchFor, startIndex, endIndex, ignoreCase);
            if (stringRange == null)
                return null;
            while (stringRange != null)
            {
                resultList.Add(stringRange);
                startIndex = stringRange.End;
                stringRange = FindNextOccurenceForwards(s, toSearchFor, startIndex, endIndex, ignoreCase);
            }

            return resultList;
        }

        public static List<StringRange> FindAllOccurencesBackwards(string s, string toSearchFor, int startIndex = -1, int endIndex = 0, bool ignoreCase = false)
        {
            if (ignoreCase)
                s = s.ToLower();
            var resultList = new List<StringRange>();
            var stringRange = FindNextOccurenceBackwards(s, toSearchFor, startIndex, endIndex, ignoreCase);
            if (stringRange == null)
                return null;
            while (stringRange != null)
            {
                resultList.Add(stringRange);
                startIndex = stringRange.Start - 1;
                stringRange = FindNextOccurenceForwards(s, toSearchFor, startIndex, endIndex, ignoreCase);
            }

            return resultList;
        }

        public static int FindNextOccurenceNotCharacterForwards(string s, char character, int startIndex = 0, int endIndex = -1, bool ignoreCase = false)
        {
            return FindNextOccurenceNotInCharArrayForwards(s, new char[] { character }, startIndex, endIndex, ignoreCase);
        }

        public static int FindNextOccurenceNotCharacterBackwards(string s, char character, int startIndex = 0, int endIndex = -1, bool ignoreCase = false)
        {
            return FindNextOccurenceNotInCharArrayBackwards(s, new char[] { character }, startIndex, endIndex, ignoreCase);
        }

        public static int FindNextOccurenceNotInCharArrayForwards(string s, char[] characters, int startIndex = 0, int endIndex = -1, bool ignoreCase = false)
        {
            if (characters == null)
                return startIndex;
            if (ignoreCase)
                s = s.ToLower();
            if (endIndex == -1)
                endIndex = s.Length - 1;

            while(startIndex <= endIndex)
            {
                if (!characters.Contains(s[startIndex]))
                    return startIndex;
                startIndex++;
            }
            return -1;
        }

        public static int FindNextOccurenceNotInCharArrayBackwards(string s, char[] characters, int startIndex = -1, int endIndex = 0, bool ignoreCase = false)
        {
            if (characters == null)
                return startIndex;
            if (ignoreCase)
                s = s.ToLower();
            if (startIndex == -1)
                startIndex = s.Length - 1;

            while (startIndex >= endIndex)
            {
                if (!characters.Contains(s[startIndex]))
                    return startIndex;
                startIndex--;
            }
            return -1;
        }


        public static int FindNextOccurenceForwards(string s, char character, int startIndex = 0, int endIndex = -1, bool ignoreCase = false)
        {
            return FindNextOccurenceInCharArrayForwards(s, new char[] { character }, startIndex, endIndex, ignoreCase);
        }

        public static int FindNextOccurenceBackwards(string s, char character, int startIndex = 0, int endIndex = -1, bool ignoreCase = false)
        {
            return FindNextOccurenceInCharArrayBackwards(s, new char[] { character }, startIndex, endIndex, ignoreCase);
        }

        public static int FindNextOccurenceInCharArrayForwards(string s, char[] characters, int startIndex = 0, int endIndex = -1, bool ignoreCase = false)
        {
            if (characters == null)
                return startIndex;
            if (ignoreCase)
                s = s.ToLower();
            if (endIndex == -1)
                endIndex = s.Length - 1;

            while (startIndex <= endIndex)
            {
                if (characters.Contains(s[startIndex]))
                    return startIndex;
                startIndex++;
            }
            return -1;
        }

        public static int FindNextOccurenceInCharArrayBackwards(string s, char[] characters, int startIndex = -1, int endIndex = 0, bool ignoreCase = false)
        {
            if (characters == null)
                return startIndex;
            if (ignoreCase)
                s = s.ToLower();
            if (startIndex == -1)
                startIndex = s.Length - 1;

            while (startIndex >= endIndex)
            {
                if (characters.Contains(s[startIndex]))
                    return startIndex;
                startIndex--;
            }
            return -1;
        }

    }
}
