﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CodeGenerationLib
{
    public class StringRange
    {
        public StringRange(int start, int end)
        {
            Start = start;
            End = end;
        }

        public int Start { get; set; }
        public int End { get; set; }

        public int GetLength()
        {
            return End - Start + 1;
        }

        public override string ToString()
        {
            return $"Start: {Start} - Ende: {End}";
        }
    }
}
