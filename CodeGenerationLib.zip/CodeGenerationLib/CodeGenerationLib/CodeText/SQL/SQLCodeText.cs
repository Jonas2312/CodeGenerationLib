﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CodeGenerationLib.CodeText.SQL
{
    public class SQLCodeText
    {
        public void AddTable(string name, List<SQLProperty> properties)
        {

        } 
    }
}
