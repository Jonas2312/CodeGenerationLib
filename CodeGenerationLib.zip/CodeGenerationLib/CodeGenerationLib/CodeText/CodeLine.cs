﻿namespace CodeGenerationLib.CodeText
{
    public class CodeLine
    {

        public int NumberOfIdents { get; set; }
        public string Content { get; set; }

        public CodeLine(string content, int numberOfIdents)
        {
            Content = content;
            NumberOfIdents = numberOfIdents;
        }

        public static implicit operator string(CodeLine line)
        {
            string s = string.Empty;
            for (int i = 0; i < line.NumberOfIdents; i++)
            {
                s += "\t";
            }
            s += line.Content;
            return s;
        }
    }
}