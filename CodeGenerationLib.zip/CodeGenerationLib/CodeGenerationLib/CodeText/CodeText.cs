﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CodeGenerationLib.CodeText
{
    public class CodeTextObject
    {
        public string this[int key]
        {
            get => CodeLines[key].Content;
            set => CodeLines[key].Content = value;
        }

        public List<CodeLine> CodeLines { get; set; }
        public int CurrentCaretIndex { get; set; }

        public CodeTextObject()
        {
            CodeLines = new List<CodeLine>();
            CodeLines.Add(new CodeLine("", 0));
            CurrentCaretIndex = 0;
        }

        public void Append(string s)
        {
            CodeLines[CurrentCaretIndex].Content += s;
        }

        public void InsertLine(string s, int relativeNumberOfIdents = 0, bool ifEmptyAppend=true)
        {
            if (ifEmptyAppend && (CodeLines[CurrentCaretIndex].Content == null || CodeLines[CurrentCaretIndex].Content.Length == 0))
            {
                CodeLines[CurrentCaretIndex].NumberOfIdents += relativeNumberOfIdents;
                Append(s);
                return;
            }
            InsertLineAfter(s, CurrentCaretIndex, CodeLines[CurrentCaretIndex].NumberOfIdents + relativeNumberOfIdents);
            CurrentCaretIndex++;
        }

        public void InsertEmptyLines(int numberOfLines = 1)
        {
            for(int i = 0; i < numberOfLines; i++)
                InsertLine(" ", ifEmptyAppend:false);
            
        }

        public void InsertLineBefore(string s, int index = -1, int numberOfIdents = -1)
        {
            if (index == -1)
                index = CodeLines.Count() - 1;
            if (numberOfIdents == -1)
                numberOfIdents = CodeLines[index].NumberOfIdents;
            CodeLines.Insert(index, new CodeLine(s, numberOfIdents));
        }

        public void InsertLineAfter(string s, int index = -1, int numberOfIdents = -1)
        {
            if (index == -1)
                index = CodeLines.Count() - 1;
            if (numberOfIdents == -1)
                numberOfIdents = CodeLines[index].NumberOfIdents;
            if (index == CodeLines.Count - 1)
            {
                CodeLines.Add(new CodeLine(s, numberOfIdents));
                return;
            }
            CodeLines.Insert(index + 1, new CodeLine(s, numberOfIdents));
        }

        public static implicit operator string(CodeTextObject codeTextObject)
        {
            string s = string.Empty;
            foreach(var line in codeTextObject.CodeLines)
            {                
                s += line + "\n";
            }
            return s;
        }
    }
}
