﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CodeGenerationLib.CodeText
{
    public enum CaretPositionManipulation
    {
        Before = 0,
        Inside = 1,
        Afterwards = 2
    }
}
