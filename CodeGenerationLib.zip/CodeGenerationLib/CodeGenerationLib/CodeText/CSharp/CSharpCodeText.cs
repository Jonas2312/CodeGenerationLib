﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CodeGenerationLib.CodeText
{
    public class CSharpCodeText : CodeTextObject
    {

        public void AddBraces(CaretPositionManipulation newCaretPosition = CaretPositionManipulation.Inside)
        {
            InsertLine("{");
            InsertLine("", 1);
            InsertLine("}", -1, false);

            switch (newCaretPosition)
            {
                case CaretPositionManipulation.Before:
                    CurrentCaretIndex = CurrentCaretIndex - 3;
                    break;
                case CaretPositionManipulation.Inside:
                    CurrentCaretIndex = CurrentCaretIndex - 1;
                    break;
                case CaretPositionManipulation.Afterwards:
                    break;
                default:
                    break;
            }
        }

        public void ToNextClosedBrace(int numberOfBracesToSkip = 1)
        {
            while(numberOfBracesToSkip > 0 && CurrentCaretIndex < CodeLines.Count - 1)
            {
                CurrentCaretIndex++;
                if (CodeLines[CurrentCaretIndex].Content.Equals("}"))
                    numberOfBracesToSkip--;
            }
        }

        public void AddClass(string name, List<string> inheritsFrom, List<CSharpProperty> properties, string attribute = null, bool onPropertyChanged = true)
        {
            if (attribute != null && attribute.Length != 0)
                InsertLine(attribute);
            InsertLine($"public class {name}");
            if(inheritsFrom != null && inheritsFrom.Count > 0)
            {
                Append(" : ");
                for (int i = 0; i < inheritsFrom.Count; i++)
                {
                    string inheritance = inheritsFrom[i];
                    Append(inheritance);
                    if (i < inheritsFrom.Count - 1)
                        Append(", ");
                }
            }
            AddBraces();
            foreach (var property in properties)
                InsertLine($"private {property.Type} {NamingConventionService.ToBackingField(property.Name)};");
            InsertEmptyLines(2);
            foreach (var property in properties)
            {
                if (property.Attribute != null)
                    InsertLine(property.Attribute);
                InsertLine($"public {property.Type} {NamingConventionService.ToFirstLetterUpper(property.Name)}");
                AddBraces();
                InsertLine("get");
                AddBraces();
                InsertLine($"return {NamingConventionService.ToBackingField(property.Name)};");
                ToNextClosedBrace();
                InsertLine("set");
                AddBraces();
                InsertLine($"{NamingConventionService.ToBackingField(property.Name)} = value;");
                if(onPropertyChanged)
                    InsertLine("OnPropertyChanged();");
                ToNextClosedBrace(2);
                InsertEmptyLines(1);
            }
            ToNextClosedBrace();
        }

        public void AddInterface(string name, List<string> inheritsFrom, List<CSharpProperty> properties)
        {
            InsertLine($"public interface {name}");
            if (inheritsFrom != null && inheritsFrom.Count > 0)
            {
                Append(" : ");
                for (int i = 0; i < inheritsFrom.Count; i++)
                {
                    string inheritance = inheritsFrom[i];
                    Append(inheritance);
                    if (i < inheritsFrom.Count - 1)
                        Append(", ");
                }
            }
            AddBraces();
            foreach (var property in properties)
                InsertLine($"{property.Type} {NamingConventionService.ToFirstLetterUpper(property.Name)}" + " { get; set;}");
        }
    }
}
