﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CodeGenerationLib.CodeText
{
    public class CSharpProperty
    {
        public CSharpProperty(string type, string name, string attribute)
        {
            Type = type;
            Name = name;
            Attribute = attribute;
        }

        public string Type { get; set; }
        public string Name { get; set; }
        public string Attribute { get; set; }

    }
}
