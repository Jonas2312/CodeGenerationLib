﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CodeGenerationLib
{
    public static class NamingConventionService
    {
       
        public static string ToFirstLetterLower(string s)
        {
            if (s == null || s.Length == 0)
                return s;
            var result = s[0].ToString().ToLower() + s.Substring(1);
            return result;
        }

        public static string ToBackingField(string s)
        {
            string result = string.Empty;
            int index = 0;
            while(index < s.Length && s[index].ToString().ToUpper() == s[index].ToString())
            {
                result += s[index].ToString().ToLower();
                index++;
            }
            result = "_" + result + s.Substring(index);
            return result;
        }

        public static string ToFirstLetterUpper(string s)
        {
            if (s == null || s.Length == 0)
                return s;
            var result = s[0].ToString().ToUpper() + s.Substring(1);
            return result;
        }

    }
}
