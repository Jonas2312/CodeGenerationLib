﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CodeGenerationLib
{
    public static class StringReverseService
    {
        public static string Reverse(string s)
        {
            if (s == null) return null;

            char[] array = s.ToCharArray();
            Array.Reverse(array);
            return new String(array);
        }
    }
}
