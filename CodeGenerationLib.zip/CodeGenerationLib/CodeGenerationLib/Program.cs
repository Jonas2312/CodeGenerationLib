﻿using CodeGenerationLib.CodeText;
using System;
using System.Collections.Generic;

namespace CodeGenerationLib
{
    class Program
    {
        static void Main(string[] args)
        {
            var property = new CSharpProperty("int", "Id", "[Mapping(ColumnName = \"id\")]");
            var property2 = new CSharpProperty("string", "Name", "[Mapping(ColumnName = \"name\")]");
            var property3 = new CSharpProperty("DateTime", "DOEOM", "[Mapping(ColumnName = \"doeom\")]");
            var code = new CSharpCodeText();
            code.AddClass("MyClass", new List<string>() { "IMyClass" }, new List<CSharpProperty>() { property, property2, property3 }, "[Database(TableName = \"mytable\")]", true);
            
            code.AddInterface("IMyClass", null, new List<CSharpProperty>() { property, property2, property3 });
            Console.WriteLine(code);
            Console.WriteLine(StringSearchService.FindNextOccurenceBackwards(code, "DateTime"));
        }
    }
}
